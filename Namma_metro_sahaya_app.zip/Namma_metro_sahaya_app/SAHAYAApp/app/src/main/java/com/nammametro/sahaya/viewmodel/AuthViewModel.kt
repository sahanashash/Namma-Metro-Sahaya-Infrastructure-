package com.nammametro.sahaya.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.PhoneAuthCredential
import com.nammametro.sahaya.data.model.User
import com.nammametro.sahaya.data.repository.UserRepository
import com.nammametro.sahaya.utils.Resource
import kotlinx.coroutines.launch

class AuthViewModel(private val repository: UserRepository) : ViewModel() {

    private val _authState = MutableLiveData<Resource<User>>(Resource.Idle)
    val authState: LiveData<Resource<User>> = _authState

    val isLoggedIn get() = repository.isLoggedIn

    fun signInWithCredential(credential: PhoneAuthCredential) {
        _authState.value = Resource.Loading
        viewModelScope.launch {
            _authState.value = repository.signInWithCredential(credential)
        }
    }

    fun signOut() {
        repository.signOut()
    }
}
