package com.nammametro.sahaya.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.google.firebase.FirebaseException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.nammametro.sahaya.SAHAYAApplication
import com.nammametro.sahaya.databinding.ActivityAuthBinding
import com.nammametro.sahaya.ui.MainActivity
import com.nammametro.sahaya.utils.Resource
import com.nammametro.sahaya.viewmodel.AuthViewModel
import com.nammametro.sahaya.viewmodel.AuthViewModelFactory
import java.util.concurrent.TimeUnit

class AuthActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAuthBinding
    private lateinit var viewModel: AuthViewModel
    private var verificationId: String = ""
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAuthBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as SAHAYAApplication
        viewModel = ViewModelProvider(
            this,
            AuthViewModelFactory(app.userRepository)
        )[AuthViewModel::class.java]

        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        // Send OTP button
        binding.btnSendOtp.setOnClickListener {
            val phone = binding.etPhone.text.toString().trim()
            if (phone.length != 10) {
                binding.etPhone.error = "Enter valid 10-digit phone number"
                return@setOnClickListener
            }
            sendOtp("+91$phone")
        }

        // Verify OTP button
        binding.btnVerifyOtp.setOnClickListener {
            val otp = binding.etOtp.text.toString().trim()
            if (otp.length != 6) {
                binding.etOtp.error = "Enter 6-digit OTP"
                return@setOnClickListener
            }
            verifyOtp(otp)
        }

        // Resend OTP
        binding.tvResendOtp.setOnClickListener {
            val phone = binding.etPhone.text.toString().trim()
            if (phone.length == 10) {
                resendToken?.let { token ->
                    sendOtp("+91$phone", token)
                }
            }
        }
    }

    private fun sendOtp(phoneNumber: String, resendToken: PhoneAuthProvider.ForceResendingToken? = null) {
        binding.progressBar.visibility = View.VISIBLE
        binding.btnSendOtp.isEnabled = false

        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                // Auto-retrieval or instant verification
                viewModel.signInWithCredential(credential)
            }

            override fun onVerificationFailed(e: FirebaseException) {
                binding.progressBar.visibility = View.GONE
                binding.btnSendOtp.isEnabled = true
                Toast.makeText(this@AuthActivity, "OTP failed: ${e.message}", Toast.LENGTH_LONG).show()
            }

            override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                verificationId = id
                this@AuthActivity.resendToken = token
                binding.progressBar.visibility = View.GONE
                binding.btnSendOtp.isEnabled = true
                // Show OTP input
                binding.layoutPhone.visibility = View.GONE
                binding.layoutOtp.visibility = View.VISIBLE
                Toast.makeText(this@AuthActivity, "OTP sent to $phoneNumber", Toast.LENGTH_SHORT).show()
            }
        }

        val optionsBuilder = PhoneAuthOptions.newBuilder(FirebaseAuth.getInstance())
            .setPhoneNumber(phoneNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(callbacks)

        resendToken?.let { optionsBuilder.setForceResendingToken(it) }

        PhoneAuthProvider.verifyPhoneNumber(optionsBuilder.build())
    }

    private fun verifyOtp(otp: String) {
        binding.progressBar.visibility = View.VISIBLE
        binding.btnVerifyOtp.isEnabled = false
        val credential = PhoneAuthProvider.getCredential(verificationId, otp)
        viewModel.signInWithCredential(credential)
    }

    private fun observeViewModel() {
        viewModel.authState.observe(this) { state ->
            when (state) {
                is Resource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
                is Resource.Success -> {
                    binding.progressBar.visibility = View.GONE
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }
                is Resource.Error -> {
                    binding.progressBar.visibility = View.GONE
                    binding.btnVerifyOtp.isEnabled = true
                    Toast.makeText(this, state.message, Toast.LENGTH_LONG).show()
                }
                else -> {
                    binding.progressBar.visibility = View.GONE
                }
            }
        }
    }
}
