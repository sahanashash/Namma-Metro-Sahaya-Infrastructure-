package com.nammametro.sahaya.ui.complaint

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.nammametro.sahaya.R
import com.nammametro.sahaya.SAHAYAApplication
import com.nammametro.sahaya.databinding.FragmentMyComplaintsBinding
import com.nammametro.sahaya.utils.Resource
import com.nammametro.sahaya.viewmodel.ComplaintViewModel
import com.nammametro.sahaya.viewmodel.ComplaintViewModelFactory

class MyComplaintsFragment : Fragment() {

    private var _binding: FragmentMyComplaintsBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: ComplaintViewModel
    private lateinit var adapter: ComplaintAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMyComplaintsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = requireActivity().application as SAHAYAApplication
        viewModel = ViewModelProvider(
            this,
            ComplaintViewModelFactory(app.complaintRepository, app.userRepository)
        )[ComplaintViewModel::class.java]

        setupRecyclerView()
        setupFilterChips()
        observeViewModel()
        viewModel.loadMyComplaints()
    }

    private fun setupRecyclerView() {
        adapter = ComplaintAdapter { complaint ->
            val bundle = Bundle().apply { putString("complaintId", complaint.id) }
            findNavController().navigate(R.id.action_myComplaints_to_complaintDetail, bundle)
        }
        binding.rvComplaints.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@MyComplaintsFragment.adapter
        }
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.loadMyComplaints()
        }
    }

    private fun setupFilterChips() {
        binding.chipAll.setOnClickListener { viewModel.loadMyComplaints() }
        binding.chipOpen.setOnClickListener { viewModel.loadMyComplaints(status = "OPEN") }
        binding.chipInProgress.setOnClickListener { viewModel.loadMyComplaints(status = "IN_PROGRESS") }
        binding.chipResolved.setOnClickListener { viewModel.loadMyComplaints(status = "RESOLVED") }
    }

    private fun observeViewModel() {
        viewModel.complaintsState.observe(viewLifecycleOwner) { state ->
            binding.swipeRefresh.isRefreshing = false
            when (state) {
                is Resource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.tvEmpty.visibility = View.GONE
                }
                is Resource.Success -> {
                    binding.progressBar.visibility = View.GONE
                    val items = state.data.items
                    adapter.submitList(items)
                    binding.tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                }
                is Resource.Error -> {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(requireContext(), state.message, Toast.LENGTH_SHORT).show()
                }
                else -> binding.progressBar.visibility = View.GONE
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
