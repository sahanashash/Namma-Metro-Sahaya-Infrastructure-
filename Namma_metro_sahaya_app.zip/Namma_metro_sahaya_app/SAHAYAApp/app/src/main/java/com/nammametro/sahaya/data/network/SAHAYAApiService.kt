package com.nammametro.sahaya.data.network

import com.nammametro.sahaya.data.model.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface SAHAYAApiService {

    // ── Auth ──────────────────────────────────────────
    @POST("auth/register")
    suspend fun registerUser(@Body user: User): Response<ApiResponse<User>>

    @GET("auth/profile")
    suspend fun getProfile(@Header("Authorization") token: String): Response<ApiResponse<User>>

    @PUT("auth/profile")
    suspend fun updateProfile(
        @Header("Authorization") token: String,
        @Body user: User
    ): Response<ApiResponse<User>>

    // ── Complaints ────────────────────────────────────
    @POST("complaints")
    suspend fun submitComplaint(
        @Header("Authorization") token: String,
        @Body request: ComplaintRequest
    ): Response<ApiResponse<Complaint>>

    @GET("complaints")
    suspend fun getMyComplaints(
        @Header("Authorization") token: String,
        @Query("page") page: Int = 1,
        @Query("limit") limit: Int = 20,
        @Query("status") status: String? = null
    ): Response<ApiResponse<PaginatedResponse<Complaint>>>

    @GET("complaints/{id}")
    suspend fun getComplaintById(
        @Header("Authorization") token: String,
        @Path("id") id: String
    ): Response<ApiResponse<Complaint>>

    @Multipart
    @POST("complaints/upload-image")
    suspend fun uploadComplaintImage(
        @Header("Authorization") token: String,
        @Part image: MultipartBody.Part,
        @Part("complaintId") complaintId: RequestBody
    ): Response<ApiResponse<String>>

    // ── Train Info ────────────────────────────────────
    @GET("trains/status")
    suspend fun getAllLineStatus(): Response<ApiResponse<List<TrainStatus>>>

    @GET("trains/schedule/{stationId}")
    suspend fun getTrainSchedule(
        @Path("stationId") stationId: String,
        @Query("direction") direction: String = "BOTH"
    ): Response<ApiResponse<TrainSchedule>>

    @GET("stations")
    suspend fun getAllStations(): Response<ApiResponse<List<Station>>>

    @GET("stations/search")
    suspend fun searchStations(
        @Query("query") query: String
    ): Response<ApiResponse<List<Station>>>

    @GET("trains/fare")
    suspend fun getFare(
        @Query("fromStation") fromStation: String,
        @Query("toStation") toStation: String
    ): Response<ApiResponse<Int>>

    // ── Lost & Found ──────────────────────────────────
    @POST("lost-found")
    suspend fun reportLostItem(
        @Header("Authorization") token: String,
        @Body item: LostItem
    ): Response<ApiResponse<LostItem>>

    @GET("lost-found")
    suspend fun getMyLostItems(
        @Header("Authorization") token: String
    ): Response<ApiResponse<List<LostItem>>>

    @GET("lost-found/search")
    suspend fun searchFoundItems(
        @Query("itemType") itemType: String,
        @Query("station") station: String? = null,
        @Query("date") date: String? = null
    ): Response<ApiResponse<List<LostItem>>>

    // ── Notifications ─────────────────────────────────
    @GET("notifications")
    suspend fun getNotifications(
        @Header("Authorization") token: String,
        @Query("page") page: Int = 1
    ): Response<ApiResponse<PaginatedResponse<SAHAYANotification>>>

    @PUT("notifications/{id}/read")
    suspend fun markNotificationRead(
        @Header("Authorization") token: String,
        @Path("id") id: String
    ): Response<ApiResponse<Boolean>>

    @POST("notifications/token")
    suspend fun registerFcmToken(
        @Header("Authorization") token: String,
        @Body body: Map<String, String>
    ): Response<ApiResponse<Boolean>>
}
