package com.nammametro.sahaya.data.repository

import com.nammametro.sahaya.data.model.Station
import com.nammametro.sahaya.data.model.TrainSchedule
import com.nammametro.sahaya.data.model.TrainStatus
import com.nammametro.sahaya.data.network.SAHAYAApiService
import com.nammametro.sahaya.utils.Resource
import com.nammametro.sahaya.utils.safeApiCall

class TrainRepository(private val api: SAHAYAApiService) {

    suspend fun getAllLineStatus(): Resource<List<TrainStatus>> =
        safeApiCall { api.getAllLineStatus() }

    suspend fun getTrainSchedule(stationId: String, direction: String = "BOTH"): Resource<TrainSchedule> =
        safeApiCall { api.getTrainSchedule(stationId, direction) }

    suspend fun getAllStations(): Resource<List<Station>> =
        safeApiCall { api.getAllStations() }

    suspend fun searchStations(query: String): Resource<List<Station>> =
        safeApiCall { api.searchStations(query) }

    suspend fun getFare(from: String, to: String): Resource<Int> =
        safeApiCall { api.getFare(from, to) }
}
