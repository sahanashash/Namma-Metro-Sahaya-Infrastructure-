package com.nammametro.sahaya.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nammametro.sahaya.data.model.Complaint
import com.nammametro.sahaya.data.model.ComplaintRequest
import com.nammametro.sahaya.data.model.PaginatedResponse
import com.nammametro.sahaya.data.repository.ComplaintRepository
import com.nammametro.sahaya.data.repository.UserRepository
import com.nammametro.sahaya.utils.Resource
import kotlinx.coroutines.launch
import java.io.File

class ComplaintViewModel(
    private val complaintRepository: ComplaintRepository,
    private val userRepository: UserRepository
) : ViewModel() {

    private val _submitState = MutableLiveData<Resource<Complaint>>(Resource.Idle)
    val submitState: LiveData<Resource<Complaint>> = _submitState

    private val _complaintsState = MutableLiveData<Resource<PaginatedResponse<Complaint>>>(Resource.Idle)
    val complaintsState: LiveData<Resource<PaginatedResponse<Complaint>>> = _complaintsState

    private val _complaintDetail = MutableLiveData<Resource<Complaint>>(Resource.Idle)
    val complaintDetail: LiveData<Resource<Complaint>> = _complaintDetail

    private val _uploadState = MutableLiveData<Resource<String>>(Resource.Idle)
    val uploadState: LiveData<Resource<String>> = _uploadState

    // Selected category for multi-step form
    var selectedCategory: String = ""
    var selectedSubCategory: String = ""

    fun submitComplaint(request: ComplaintRequest) {
        _submitState.value = Resource.Loading
        viewModelScope.launch {
            val token = userRepository.getBearerToken()
            if (token == null) {
                _submitState.value = Resource.Error("Please login again")
                return@launch
            }
            _submitState.value = complaintRepository.submitComplaint(token, request)
        }
    }

    fun loadMyComplaints(status: String? = null) {
        _complaintsState.value = Resource.Loading
        viewModelScope.launch {
            val token = userRepository.getBearerToken()
            if (token == null) {
                _complaintsState.value = Resource.Error("Please login again")
                return@launch
            }
            _complaintsState.value = complaintRepository.getMyComplaints(token, status = status)
        }
    }

    fun loadComplaintDetail(id: String) {
        _complaintDetail.value = Resource.Loading
        viewModelScope.launch {
            val token = userRepository.getBearerToken()
            if (token == null) {
                _complaintDetail.value = Resource.Error("Please login again")
                return@launch
            }
            _complaintDetail.value = complaintRepository.getComplaintById(token, id)
        }
    }

    fun uploadImage(file: File, complaintId: String) {
        _uploadState.value = Resource.Loading
        viewModelScope.launch {
            val token = userRepository.getBearerToken()
            if (token == null) {
                _uploadState.value = Resource.Error("Please login again")
                return@launch
            }
            _uploadState.value = complaintRepository.uploadImage(token, file, complaintId)
        }
    }

    fun resetSubmitState() {
        _submitState.value = Resource.Idle
    }
}
