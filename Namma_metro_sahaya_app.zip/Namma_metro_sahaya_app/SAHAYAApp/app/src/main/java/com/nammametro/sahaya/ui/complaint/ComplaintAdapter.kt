package com.nammametro.sahaya.ui.complaint

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nammametro.sahaya.R
import com.nammametro.sahaya.data.model.Complaint
import com.nammametro.sahaya.databinding.ItemComplaintBinding
import java.text.SimpleDateFormat
import java.util.*

class ComplaintAdapter(
    private val onItemClick: (Complaint) -> Unit
) : ListAdapter<Complaint, ComplaintAdapter.ViewHolder>(DiffCallback) {

    inner class ViewHolder(private val binding: ItemComplaintBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(complaint: Complaint) {
            binding.tvTicketNumber.text = complaint.ticketNumber
            binding.tvCategory.text = complaint.category.replace("_", " ")
            binding.tvDescription.text = complaint.description
            binding.tvStation.text = complaint.stationName

            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
            binding.tvDate.text = sdf.format(Date(complaint.createdAt))

            // Status badge color
            val (statusLabel, colorRes) = when (complaint.status) {
                "OPEN" -> "Open" to R.color.status_open
                "IN_PROGRESS" -> "In Progress" to R.color.status_in_progress
                "RESOLVED" -> "Resolved" to R.color.status_resolved
                "CLOSED" -> "Closed" to R.color.status_closed
                else -> complaint.status to R.color.status_open
            }
            binding.tvStatus.text = statusLabel
            binding.tvStatus.backgroundTintList =
                ContextCompat.getColorStateList(binding.root.context, colorRes)

            // Priority dot
            val priorityColor = when (complaint.priority) {
                "HIGH", "URGENT" -> R.color.priority_high
                "MEDIUM" -> R.color.priority_medium
                else -> R.color.priority_low
            }
            binding.viewPriorityDot.setBackgroundColor(
                ContextCompat.getColor(binding.root.context, priorityColor)
            )

            binding.root.setOnClickListener { onItemClick(complaint) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemComplaintBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object DiffCallback : DiffUtil.ItemCallback<Complaint>() {
        override fun areItemsTheSame(old: Complaint, new: Complaint) = old.id == new.id
        override fun areContentsTheSame(old: Complaint, new: Complaint) = old == new
    }
}
