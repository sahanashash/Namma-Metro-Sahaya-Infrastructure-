package com.nammametro.sahaya.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.nammametro.sahaya.data.repository.ComplaintRepository
import com.nammametro.sahaya.data.repository.TrainRepository
import com.nammametro.sahaya.data.repository.UserRepository

class AuthViewModelFactory(private val repo: UserRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return AuthViewModel(repo) as T
    }
}

class ComplaintViewModelFactory(
    private val complaintRepo: ComplaintRepository,
    private val userRepo: UserRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return ComplaintViewModel(complaintRepo, userRepo) as T
    }
}

class TrainViewModelFactory(private val repo: TrainRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return TrainViewModel(repo) as T
    }
}
