package com.nammametro.sahaya.ui.traininfo

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.nammametro.sahaya.SAHAYAApplication
import com.nammametro.sahaya.databinding.FragmentTrainInfoBinding
import com.nammametro.sahaya.utils.Resource
import com.nammametro.sahaya.viewmodel.TrainViewModel
import com.nammametro.sahaya.viewmodel.TrainViewModelFactory

class TrainInfoFragment : Fragment() {

    private var _binding: FragmentTrainInfoBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: TrainViewModel
    private lateinit var lineStatusAdapter: LineStatusAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTrainInfoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = requireActivity().application as SAHAYAApplication
        viewModel = ViewModelProvider(
            this, TrainViewModelFactory(app.trainRepository)
        )[TrainViewModel::class.java]

        setupRecyclerView()
        observeViewModel()
        viewModel.loadLineStatus()
        viewModel.loadAllStations()
    }

    private fun setupRecyclerView() {
        lineStatusAdapter = LineStatusAdapter()
        binding.rvLineStatus.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = lineStatusAdapter
        }
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.loadLineStatus()
        }

        // Station search
        binding.etSearchStation.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.searchStations(s.toString())
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun observeViewModel() {
        viewModel.lineStatus.observe(viewLifecycleOwner) { state ->
            binding.swipeRefresh.isRefreshing = false
            when (state) {
                is Resource.Loading -> binding.progressBar.visibility = View.VISIBLE
                is Resource.Success -> {
                    binding.progressBar.visibility = View.GONE
                    lineStatusAdapter.submitList(state.data)
                }
                is Resource.Error -> {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(requireContext(), state.message, Toast.LENGTH_SHORT).show()
                }
                else -> binding.progressBar.visibility = View.GONE
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
