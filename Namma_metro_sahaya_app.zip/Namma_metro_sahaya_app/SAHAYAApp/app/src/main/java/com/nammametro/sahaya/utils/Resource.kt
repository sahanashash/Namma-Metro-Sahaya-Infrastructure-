package com.nammametro.sahaya.utils

/**
 * Sealed class representing UI state for any data fetch.
 * Wrap all LiveData / StateFlow emissions in this.
 */
sealed class Resource<out T> {
    data class Success<T>(val data: T) : Resource<T>()
    data class Error(val message: String, val code: Int? = null) : Resource<Nothing>()
    object Loading : Resource<Nothing>()
    object Idle : Resource<Nothing>()

    val isLoading get() = this is Loading
    val isSuccess get() = this is Success
    val isError get() = this is Error

    fun getOrNull(): T? = if (this is Success) data else null
}

/**
 * Extension to safely call Retrofit and wrap in Resource.
 */
suspend fun <T> safeApiCall(call: suspend () -> retrofit2.Response<com.nammametro.sahaya.data.model.ApiResponse<T>>): Resource<T> {
    return try {
        val response = call()
        if (response.isSuccessful) {
            val body = response.body()
            if (body?.success == true && body.data != null) {
                Resource.Success(body.data)
            } else {
                Resource.Error(body?.message ?: "Unknown error", response.code())
            }
        } else {
            Resource.Error("Server error: ${response.code()}", response.code())
        }
    } catch (e: java.net.UnknownHostException) {
        Resource.Error("No internet connection. Please check your network.")
    } catch (e: java.net.SocketTimeoutException) {
        Resource.Error("Request timed out. Please try again.")
    } catch (e: Exception) {
        Resource.Error(e.localizedMessage ?: "Something went wrong")
    }
}
