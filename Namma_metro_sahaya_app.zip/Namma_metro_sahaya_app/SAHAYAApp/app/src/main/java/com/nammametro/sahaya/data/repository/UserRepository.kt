package com.nammametro.sahaya.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.firestore.FirebaseFirestore
import com.nammametro.sahaya.data.model.User
import com.nammametro.sahaya.data.network.SAHAYAApiService
import com.nammametro.sahaya.utils.Resource
import com.nammametro.sahaya.utils.safeApiCall
import kotlinx.coroutines.tasks.await

class UserRepository(private val api: SAHAYAApiService) {

    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()

    val currentUser get() = auth.currentUser
    val isLoggedIn get() = auth.currentUser != null

    // ── Phone OTP sign-in ─────────────────────────────
    suspend fun signInWithCredential(credential: PhoneAuthCredential): Resource<User> {
        return try {
            val result = auth.signInWithCredential(credential).await()
            val firebaseUser = result.user ?: return Resource.Error("Authentication failed")
            val token = firebaseUser.getIdToken(false).await().token ?: ""

            // Register/fetch user on backend
            val user = User(
                uid = firebaseUser.uid,
                phone = firebaseUser.phoneNumber ?: "",
                name = firebaseUser.displayName ?: ""
            )
            val backendResult = safeApiCall { api.registerUser(user) }
            if (backendResult is Resource.Success) {
                Resource.Success(backendResult.data)
            } else {
                Resource.Success(user) // Fall back to Firebase user
            }
        } catch (e: Exception) {
            Resource.Error(e.localizedMessage ?: "Sign-in failed")
        }
    }

    suspend fun getProfile(): Resource<User> {
        val token = getBearerToken() ?: return Resource.Error("Not authenticated")
        return safeApiCall { api.getProfile(token) }
    }

    suspend fun updateProfile(user: User): Resource<User> {
        val token = getBearerToken() ?: return Resource.Error("Not authenticated")
        return safeApiCall { api.updateProfile(token, user) }
    }

    fun signOut() {
        auth.signOut()
    }

    suspend fun getBearerToken(): String? {
        return try {
            val token = auth.currentUser?.getIdToken(false)?.await()?.token
            if (token != null) "Bearer $token" else null
        } catch (e: Exception) {
            null
        }
    }
}
