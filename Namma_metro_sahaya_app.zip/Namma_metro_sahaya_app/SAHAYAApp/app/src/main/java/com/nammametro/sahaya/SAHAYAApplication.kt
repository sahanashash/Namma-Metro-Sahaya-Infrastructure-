package com.nammametro.sahaya

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.nammametro.sahaya.data.network.RetrofitClient
import com.nammametro.sahaya.data.repository.ComplaintRepository
import com.nammametro.sahaya.data.repository.TrainRepository
import com.nammametro.sahaya.data.repository.UserRepository

class SAHAYAApplication : Application() {

    // Simple manual DI — replace with Hilt for production
    val retrofitClient by lazy { RetrofitClient() }
    val userRepository by lazy { UserRepository(retrofitClient.apiService) }
    val complaintRepository by lazy { ComplaintRepository(retrofitClient.apiService) }
    val trainRepository by lazy { TrainRepository(retrofitClient.apiService) }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            // General alerts channel
            NotificationChannel(
                CHANNEL_ALERTS,
                "Service Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Train delays, service disruptions"
                manager.createNotificationChannel(this)
            }

            // Ticket updates channel
            NotificationChannel(
                CHANNEL_TICKETS,
                "Ticket Updates",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Status updates for your complaints and requests"
                manager.createNotificationChannel(this)
            }
        }
    }

    companion object {
        const val CHANNEL_ALERTS = "sahaya_alerts"
        const val CHANNEL_TICKETS = "sahaya_tickets"
        const val BASE_URL = "https://api.sahaya.nammametro.in/v1/"
    }
}
