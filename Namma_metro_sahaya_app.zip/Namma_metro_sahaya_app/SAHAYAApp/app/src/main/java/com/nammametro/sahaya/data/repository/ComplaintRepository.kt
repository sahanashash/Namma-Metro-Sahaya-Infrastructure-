package com.nammametro.sahaya.data.repository

import com.nammametro.sahaya.data.model.Complaint
import com.nammametro.sahaya.data.model.ComplaintRequest
import com.nammametro.sahaya.data.model.PaginatedResponse
import com.nammametro.sahaya.data.network.SAHAYAApiService
import com.nammametro.sahaya.utils.Resource
import com.nammametro.sahaya.utils.safeApiCall
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class ComplaintRepository(private val api: SAHAYAApiService) {

    suspend fun submitComplaint(
        token: String,
        request: ComplaintRequest
    ): Resource<Complaint> = safeApiCall {
        api.submitComplaint(token, request)
    }

    suspend fun getMyComplaints(
        token: String,
        page: Int = 1,
        status: String? = null
    ): Resource<PaginatedResponse<Complaint>> = safeApiCall {
        api.getMyComplaints(token, page, status = status)
    }

    suspend fun getComplaintById(
        token: String,
        id: String
    ): Resource<Complaint> = safeApiCall {
        api.getComplaintById(token, id)
    }

    suspend fun uploadImage(
        token: String,
        file: File,
        complaintId: String
    ): Resource<String> {
        val requestFile = file.asRequestBody("image/*".toMediaTypeOrNull())
        val body = MultipartBody.Part.createFormData("image", file.name, requestFile)
        val idBody = complaintId.toRequestBody("text/plain".toMediaTypeOrNull())
        return safeApiCall { api.uploadComplaintImage(token, body, idBody) }
    }
}
