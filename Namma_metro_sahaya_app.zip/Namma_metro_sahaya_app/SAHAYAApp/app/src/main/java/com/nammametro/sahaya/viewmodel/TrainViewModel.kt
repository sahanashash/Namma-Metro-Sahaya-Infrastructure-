package com.nammametro.sahaya.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nammametro.sahaya.data.model.Station
import com.nammametro.sahaya.data.model.TrainSchedule
import com.nammametro.sahaya.data.model.TrainStatus
import com.nammametro.sahaya.data.repository.TrainRepository
import com.nammametro.sahaya.utils.Resource
import kotlinx.coroutines.launch

class TrainViewModel(private val repository: TrainRepository) : ViewModel() {

    private val _lineStatus = MutableLiveData<Resource<List<TrainStatus>>>(Resource.Idle)
    val lineStatus: LiveData<Resource<List<TrainStatus>>> = _lineStatus

    private val _schedule = MutableLiveData<Resource<TrainSchedule>>(Resource.Idle)
    val schedule: LiveData<Resource<TrainSchedule>> = _schedule

    private val _stations = MutableLiveData<Resource<List<Station>>>(Resource.Idle)
    val stations: LiveData<Resource<List<Station>>> = _stations

    private val _fare = MutableLiveData<Resource<Int>>(Resource.Idle)
    val fare: LiveData<Resource<Int>> = _fare

    private val _searchResults = MutableLiveData<List<Station>>(emptyList())
    val searchResults: LiveData<List<Station>> = _searchResults

    fun loadLineStatus() {
        _lineStatus.value = Resource.Loading
        viewModelScope.launch {
            _lineStatus.value = repository.getAllLineStatus()
        }
    }

    fun loadSchedule(stationId: String) {
        _schedule.value = Resource.Loading
        viewModelScope.launch {
            _schedule.value = repository.getTrainSchedule(stationId)
        }
    }

    fun loadAllStations() {
        _stations.value = Resource.Loading
        viewModelScope.launch {
            val result = repository.getAllStations()
            _stations.value = result
            if (result is Resource.Success) {
                _searchResults.value = result.data
            }
        }
    }

    fun searchStations(query: String) {
        if (query.length < 2) {
            val all = (_stations.value as? Resource.Success)?.data ?: emptyList()
            _searchResults.value = all
            return
        }
        viewModelScope.launch {
            val result = repository.searchStations(query)
            if (result is Resource.Success) {
                _searchResults.value = result.data
            }
        }
    }

    fun calculateFare(from: String, to: String) {
        _fare.value = Resource.Loading
        viewModelScope.launch {
            _fare.value = repository.getFare(from, to)
        }
    }
}
