package com.nammametro.sahaya.ui.home

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.nammametro.sahaya.R
import com.nammametro.sahaya.SAHAYAApplication
import com.nammametro.sahaya.databinding.FragmentHomeBinding
import com.nammametro.sahaya.utils.Resource
import com.nammametro.sahaya.viewmodel.TrainViewModel
import com.nammametro.sahaya.viewmodel.TrainViewModelFactory

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var trainViewModel: TrainViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val app = requireActivity().application as SAHAYAApplication
        trainViewModel = ViewModelProvider(
            this, TrainViewModelFactory(app.trainRepository)
        )[TrainViewModel::class.java]

        setupQuickActions()
        setupServiceStatus()
        trainViewModel.loadLineStatus()
    }

    private fun setupQuickActions() {
        binding.cardRegisterComplaint.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_submitComplaint)
        }
        binding.cardMyComplaints.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_myComplaints)
        }
        binding.cardLostFound.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_lostFound)
        }
        binding.cardTrainInfo.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_trainInfo)
        }
        binding.cardFareCalc.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_fareCalc)
        }
        binding.btnCallHelpline.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:18004251515")
            }
            startActivity(intent)
        }
    }

    private fun setupServiceStatus() {
        trainViewModel.lineStatus.observe(viewLifecycleOwner) { state ->
            when (state) {
                is Resource.Success -> {
                    val hasDelay = state.data.any { it.delayMinutes > 0 }
                    binding.tvServiceStatus.text = if (hasDelay)
                        "Some delays on network" else "All lines operational"
                    binding.ivStatusIcon.setImageResource(
                        if (hasDelay) R.drawable.ic_warning else R.drawable.ic_check
                    )
                }
                is Resource.Error -> {
                    binding.tvServiceStatus.text = "Status unavailable"
                }
                else -> {}
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
