package com.nammametro.sahaya.ui.complaint

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.nammametro.sahaya.R
import com.nammametro.sahaya.SAHAYAApplication
import com.nammametro.sahaya.data.model.ComplaintCategories
import com.nammametro.sahaya.data.model.ComplaintRequest
import com.nammametro.sahaya.databinding.FragmentSubmitComplaintBinding
import com.nammametro.sahaya.utils.Resource
import com.nammametro.sahaya.viewmodel.ComplaintViewModel
import com.nammametro.sahaya.viewmodel.ComplaintViewModelFactory
import java.io.File

class SubmitComplaintFragment : Fragment() {

    private var _binding: FragmentSubmitComplaintBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: ComplaintViewModel
    private var selectedImageUri: Uri? = null

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            selectedImageUri = it
            binding.ivAttachment.setImageURI(it)
            binding.ivAttachment.visibility = View.VISIBLE
            binding.tvAttachmentName.text = "Image attached"
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSubmitComplaintBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = requireActivity().application as SAHAYAApplication
        viewModel = ViewModelProvider(
            this,
            ComplaintViewModelFactory(app.complaintRepository, app.userRepository)
        )[ComplaintViewModel::class.java]

        setupCategoryDropdown()
        setupUI()
        observeViewModel()
    }

    private fun setupCategoryDropdown() {
        val categories = ComplaintCategories.displayNames.values.toList()
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, categories)
        binding.actvCategory.setAdapter(adapter)

        binding.actvCategory.setOnItemClickListener { _, _, position, _ ->
            val categoryKey = ComplaintCategories.displayNames.keys.toList()[position]
            viewModel.selectedCategory = categoryKey
            val subCats = ComplaintCategories.categories[categoryKey] ?: emptyList()
            val subAdapter = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_dropdown_item_1line,
                subCats
            )
            binding.actvSubCategory.setAdapter(subAdapter)
            binding.actvSubCategory.setText("")
            binding.layoutSubCategory.visibility = View.VISIBLE
        }

        binding.actvSubCategory.setOnItemClickListener { _, _, position, _ ->
            val subCats = ComplaintCategories.categories[viewModel.selectedCategory] ?: emptyList()
            viewModel.selectedSubCategory = subCats[position]
        }
    }

    private fun setupUI() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
        binding.btnAttach.setOnClickListener {
            imagePickerLauncher.launch("image/*")
        }
        binding.btnSubmit.setOnClickListener {
            submitComplaint()
        }
    }

    private fun submitComplaint() {
        val category = viewModel.selectedCategory
        val subCategory = viewModel.selectedSubCategory
        val description = binding.etDescription.text.toString().trim()
        val station = binding.etStation.text.toString().trim()

        if (category.isEmpty()) {
            binding.actvCategory.error = "Please select a category"
            return
        }
        if (description.length < 20) {
            binding.etDescription.error = "Please describe the issue (min 20 characters)"
            return
        }
        if (station.isEmpty()) {
            binding.etStation.error = "Please enter the station name"
            return
        }

        val request = ComplaintRequest(
            category = category,
            subCategory = subCategory,
            description = description,
            stationName = station
        )
        viewModel.submitComplaint(request)
    }

    private fun observeViewModel() {
        viewModel.submitState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is Resource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.btnSubmit.isEnabled = false
                }
                is Resource.Success -> {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(
                        requireContext(),
                        "Complaint submitted! Ticket: ${state.data.ticketNumber}",
                        Toast.LENGTH_LONG
                    ).show()
                    viewModel.resetSubmitState()
                    findNavController().navigateUp()
                }
                is Resource.Error -> {
                    binding.progressBar.visibility = View.GONE
                    binding.btnSubmit.isEnabled = true
                    Toast.makeText(requireContext(), state.message, Toast.LENGTH_LONG).show()
                }
                else -> {
                    binding.progressBar.visibility = View.GONE
                    binding.btnSubmit.isEnabled = true
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
