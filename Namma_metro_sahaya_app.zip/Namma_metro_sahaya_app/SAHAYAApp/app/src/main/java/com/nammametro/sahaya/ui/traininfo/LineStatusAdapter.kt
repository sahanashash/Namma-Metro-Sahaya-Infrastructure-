package com.nammametro.sahaya.ui.traininfo

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nammametro.sahaya.data.model.TrainStatus
import com.nammametro.sahaya.databinding.ItemLineStatusBinding

class LineStatusAdapter : ListAdapter<TrainStatus, LineStatusAdapter.ViewHolder>(DiffCallback) {

    inner class ViewHolder(private val binding: ItemLineStatusBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(status: TrainStatus) {
            binding.tvLineName.text = status.lineName
            try {
                binding.viewLineColor.setBackgroundColor(Color.parseColor(status.lineColor))
            } catch (e: Exception) {
                binding.viewLineColor.setBackgroundColor(Color.RED)
            }

            if (status.isOperational && status.delayMinutes == 0) {
                binding.tvStatus.text = "Operational"
                binding.tvStatus.setTextColor(Color.parseColor("#1D9E75"))
                binding.tvDelay.visibility = ViewGroup.GONE
            } else if (status.delayMinutes > 0) {
                binding.tvStatus.text = "Delayed"
                binding.tvStatus.setTextColor(Color.parseColor("#EF9F27"))
                binding.tvDelay.visibility = ViewGroup.VISIBLE
                binding.tvDelay.text = "${status.delayMinutes} min delay"
            } else {
                binding.tvStatus.text = "Disrupted"
                binding.tvStatus.setTextColor(Color.parseColor("#D85A30"))
                binding.tvDelay.visibility = ViewGroup.VISIBLE
                binding.tvDelay.text = status.message
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemLineStatusBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object DiffCallback : DiffUtil.ItemCallback<TrainStatus>() {
        override fun areItemsTheSame(old: TrainStatus, new: TrainStatus) = old.lineId == new.lineId
        override fun areContentsTheSame(old: TrainStatus, new: TrainStatus) = old == new
    }
}
