package com.nammametro.sahaya.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

// ── User ──────────────────────────────────────────────
data class User(
    val uid: String = "",
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val metroCardNumber: String = "",
    val profileImageUrl: String = ""
)

// ── Complaint ─────────────────────────────────────────
@Entity(tableName = "complaints")
data class Complaint(
    @PrimaryKey val id: String = "",
    val ticketNumber: String = "",
    val category: String = "",
    val subCategory: String = "",
    val description: String = "",
    val status: String = "OPEN",       // OPEN, IN_PROGRESS, RESOLVED, CLOSED
    val priority: String = "MEDIUM",   // LOW, MEDIUM, HIGH, URGENT
    val stationName: String = "",
    val imageUrl: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val resolvedAt: Long? = null,
    val agentName: String = "",
    val agentNotes: String = ""
)

data class ComplaintRequest(
    val category: String,
    val subCategory: String,
    val description: String,
    val stationName: String,
    val imageUrl: String = ""
)

// ── Train Info ────────────────────────────────────────
data class TrainStatus(
    val lineId: String = "",
    val lineName: String = "",
    val lineColor: String = "#E32835",
    val isOperational: Boolean = true,
    val delayMinutes: Int = 0,
    val message: String = "",
    val lastUpdated: Long = System.currentTimeMillis()
)

data class Station(
    val id: String = "",
    val name: String = "",
    val lineId: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val isInterchange: Boolean = false,
    val hasElevator: Boolean = false,
    val hasParking: Boolean = false,
    val exitGates: List<String> = emptyList()
)

data class TrainSchedule(
    val stationId: String = "",
    val stationName: String = "",
    val direction: String = "",
    val nextTrains: List<NextTrain> = emptyList()
)

data class NextTrain(
    val destination: String = "",
    val arrivalMinutes: Int = 0,
    val platform: Int = 1,
    val trainId: String = ""
)

// ── Lost & Found ──────────────────────────────────────
@Entity(tableName = "lost_items")
data class LostItem(
    @PrimaryKey val id: String = "",
    val ticketNumber: String = "",
    val itemType: String = "",
    val itemDescription: String = "",
    val color: String = "",
    val lostStation: String = "",
    val lostDate: String = "",
    val lostTime: String = "",
    val trainCoach: String = "",
    val imageUrl: String = "",
    val status: String = "REPORTED",  // REPORTED, FOUND, CLAIMED, CLOSED
    val createdAt: Long = System.currentTimeMillis()
)

// ── API Response wrappers ──────────────────────────────
data class ApiResponse<T>(
    @SerializedName("success") val success: Boolean = false,
    @SerializedName("data") val data: T? = null,
    @SerializedName("message") val message: String = "",
    @SerializedName("errorCode") val errorCode: String? = null
)

data class PaginatedResponse<T>(
    val items: List<T> = emptyList(),
    val page: Int = 1,
    val totalPages: Int = 1,
    val totalCount: Int = 0
)

// ── Notification ──────────────────────────────────────
data class SAHAYANotification(
    val id: String = "",
    val title: String = "",
    val body: String = "",
    val type: String = "",  // ALERT, TICKET_UPDATE, PROMOTIONAL
    val ticketId: String? = null,
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// ── Complaint categories ──────────────────────────────
object ComplaintCategories {
    val categories = mapOf(
        "TRAIN_SERVICES" to listOf(
            "Train delay", "Train cancellation", "Overcrowding",
            "Air conditioning issue", "Cleanliness"
        ),
        "FARE_SERVICES" to listOf(
            "Card recharge issue", "Wrong fare deducted",
            "Token machine malfunction", "Refund request"
        ),
        "STATION_SERVICES" to listOf(
            "Elevator/Escalator not working", "Restroom issue",
            "Lighting issue", "Security concern"
        ),
        "STAFF_BEHAVIOR" to listOf(
            "Rude behavior", "Unhelpful staff", "Corruption"
        ),
        "OTHER" to listOf("Suggestion", "General inquiry", "Other")
    )

    val displayNames = mapOf(
        "TRAIN_SERVICES" to "Train Services",
        "FARE_SERVICES" to "Fare & Ticketing",
        "STATION_SERVICES" to "Station Services",
        "STAFF_BEHAVIOR" to "Staff Behavior",
        "OTHER" to "Other"
    )
}
