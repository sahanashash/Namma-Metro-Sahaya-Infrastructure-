# SAHAYA — Namma Metro Passenger Assistance App
## Android Studio Full Setup & Deployment Guide

---

## 1. Project Structure

```
SAHAYAApp/
├── app/
│   ├── build.gradle                        ← App dependencies
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/nammametro/sahaya/
│       │   ├── SAHAYAApplication.kt         ← App class / DI root
│       │   ├── data/
│       │   │   ├── model/Models.kt          ← All data classes
│       │   │   ├── network/
│       │   │   │   ├── SAHAYAApiService.kt  ← Retrofit endpoints
│       │   │   │   └── RetrofitClient.kt    ← OkHttp + Retrofit setup
│       │   │   └── repository/
│       │   │       ├── UserRepository.kt
│       │   │       ├── ComplaintRepository.kt
│       │   │       └── TrainRepository.kt
│       │   ├── viewmodel/
│       │   │   ├── AuthViewModel.kt
│       │   │   ├── ComplaintViewModel.kt
│       │   │   ├── TrainViewModel.kt
│       │   │   └── ViewModelFactories.kt
│       │   ├── ui/
│       │   │   ├── SplashActivity.kt
│       │   │   ├── MainActivity.kt
│       │   │   ├── auth/AuthActivity.kt
│       │   │   ├── home/HomeFragment.kt
│       │   │   ├── complaint/
│       │   │   │   ├── SubmitComplaintFragment.kt
│       │   │   │   ├── MyComplaintsFragment.kt
│       │   │   │   ├── ComplaintDetailFragment.kt
│       │   │   │   └── ComplaintAdapter.kt
│       │   │   ├── traininfo/
│       │   │   │   ├── TrainInfoFragment.kt
│       │   │   │   ├── LineStatusAdapter.kt
│       │   │   │   └── FareCalcFragment.kt
│       │   │   ├── lostfound/LostFoundFragment.kt
│       │   │   └── profile/ProfileFragment.kt
│       │   └── utils/
│       │       ├── Resource.kt              ← UI state wrapper
│       │       └── SAHAYAMessagingService.kt
│       └── res/
│           ├── layout/                      ← All XML layouts
│           ├── navigation/nav_graph.xml
│           ├── menu/bottom_nav_menu.xml
│           ├── values/
│           │   ├── strings.xml
│           │   ├── colors.xml
│           │   └── themes.xml
│           └── xml/file_paths.xml
├── build.gradle                             ← Root build file
└── settings.gradle
```

---

## 2. Prerequisites

| Tool | Version |
|------|---------|
| Android Studio | Hedgehog (2023.1.1) or newer |
| JDK | 17 |
| Kotlin | 1.9.0 |
| Min SDK | 24 (Android 7.0) |
| Target SDK | 34 (Android 14) |
| Gradle | 8.1.2 |

---

## 3. Firebase Setup (Required)

### Step 1: Create Firebase Project
1. Go to https://console.firebase.google.com
2. Click "Add project" → Name it "SAHAYANammaMetro"
3. Enable Google Analytics (optional but recommended)

### Step 2: Add Android App
1. In Firebase console → Project Settings → Add app → Android
2. Package name: `com.nammametro.sahaya`
3. App nickname: `SAHAYA`
4. Download `google-services.json`
5. Place it at: `app/google-services.json`

### Step 3: Enable Services
In Firebase Console enable:
- **Authentication** → Sign-in method → Phone
- **Cloud Firestore** → Create database (production mode)
- **Cloud Messaging** (FCM) — enabled by default
- **Analytics** — enabled by default

### Step 4: Phone Auth (India)
- In Authentication → Settings → Authorized domains, add your domain
- For testing: Add test phone numbers in Authentication → Sign-in method → Phone → Test phone numbers
  ```
  +91 9999999999  →  OTP: 123456
  ```

---

## 4. Android Studio Setup

### Step 1: Clone/Open Project
```bash
# Open Android Studio → File → Open → select SAHAYAApp folder
```

### Step 2: Sync Gradle
```
Android Studio will auto-prompt → Click "Sync Now"
If it fails: File → Sync Project with Gradle Files
```

### Step 3: Add google-services.json
```
Copy google-services.json to:
app/google-services.json
```

### Step 4: Update Base URL
In `SAHAYAApplication.kt`, update:
```kotlin
const val BASE_URL = "https://your-api-domain.com/v1/"
```

### Step 5: Add missing drawable resources
Create vector drawables in `res/drawable/`:
- `ic_metro_logo.xml`   — Metro logo
- `ic_complaint.xml`    — Complaint icon
- `ic_list.xml`         — List icon
- `ic_lost_found.xml`   — Lost & found icon
- `ic_train.xml`        — Train icon
- `ic_fare.xml`         — Fare/rupee icon
- `ic_phone.xml`        — Phone icon
- `ic_home.xml`         — Home icon
- `ic_person.xml`       — Profile icon
- `ic_location.xml`     — Location pin icon
- `ic_back.xml`         — Back arrow
- `ic_attach.xml`       — Attachment icon
- `ic_check.xml`        — Checkmark icon
- `ic_warning.xml`      — Warning icon
- `ic_notification.xml` — Bell icon
- `circle_dot.xml`      — Circular shape drawable
- `rounded_badge.xml`   — Rounded rectangle drawable

All standard Material icons are available via:
File → New → Vector Asset → Clip Art

### Step 6: Add color selector for bottom nav
Create `res/color/bottom_nav_color.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<selector xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:state_checked="true" android:color="@color/metro_red" />
    <item android:color="@color/text_secondary" />
</selector>
```

---

## 5. Running the App

### On Emulator
1. AVD Manager → Create Virtual Device
2. Choose Pixel 6 → API 34
3. Run → Select emulator

### On Physical Device
1. Enable Developer Options on phone
2. Enable USB Debugging
3. Connect via USB
4. Run → Select device

---

## 6. Backend API

The app expects a REST API at `BASE_URL`. You can build it with:

### Option A: Node.js + Express
```bash
npm init
npm install express firebase-admin cors helmet
```

Core endpoints to implement:
```
POST  /v1/auth/register
GET   /v1/auth/profile
POST  /v1/complaints
GET   /v1/complaints
GET   /v1/complaints/:id
GET   /v1/trains/status
GET   /v1/trains/schedule/:stationId
GET   /v1/stations
POST  /v1/lost-found
GET   /v1/notifications
```

### Option B: Firebase Firestore (no backend)
Replace Retrofit calls in repositories with Firestore calls:
```kotlin
val db = FirebaseFirestore.getInstance()
db.collection("complaints")
    .whereEqualTo("userId", uid)
    .get()
    .await()
```

### Option C: Deploy on Render/Railway
- Free tier available
- Connect GitHub repo → Auto-deploy

---

## 7. Play Store Deployment

### Step 1: Generate Keystore (one time only)
```
Android Studio → Build → Generate Signed Bundle/APK
→ Create new keystore
→ Save keystore.jks SECURELY (never commit to git)
→ Note: Key alias, Key password, Store password
```

### Step 2: Build Release APK / AAB
```
Build → Generate Signed Bundle/APK
→ Android App Bundle (AAB) — recommended for Play Store
→ Release build type
→ Select keystore → Enter passwords
```

Output: `app/release/app-release.aab`

### Step 3: Play Console Setup
1. Go to https://play.google.com/console
2. Pay $25 one-time developer fee
3. Create app → App name: "SAHAYA - Namma Metro"
4. Fill in:
   - Short description (80 chars)
   - Full description
   - Screenshots (phone + tablet)
   - Feature graphic (1024×500)
   - App icon (512×512)
   - Privacy Policy URL (required)
   - Content rating questionnaire

### Step 4: Upload AAB
```
Play Console → Production → Create new release
→ Upload .aab file
→ Add release notes
→ Review → Rollout to production
```

### Step 5: Review Timeline
- First submission: 3–7 days review
- Updates: Usually 1–2 hours after approval

---

## 8. App Signing (keystore.properties)

Add to `app/build.gradle` for CI/CD:
```groovy
// In build.gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('keystore.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile file(keystoreProperties['storeFile'])
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

Create `keystore.properties` (add to .gitignore):
```
storeFile=keystore.jks
storePassword=YOUR_STORE_PASSWORD
keyAlias=sahaya
keyPassword=YOUR_KEY_PASSWORD
```

---

## 9. Key Architecture Decisions

| Pattern | Choice | Why |
|---------|--------|-----|
| Architecture | MVVM | Lifecycle-aware, testable |
| DI | Manual (upgrade to Hilt) | Simple for learning |
| Networking | Retrofit + OkHttp | Industry standard |
| Auth | Firebase Phone OTP | No custom auth server needed |
| Push | Firebase FCM | Free, reliable |
| State | LiveData + Resource<T> | Clean error/loading states |
| Navigation | Jetpack Navigation | Back-stack handled automatically |

---

## 10. Testing

### Unit Tests
```kotlin
// test/java/com/nammametro/sahaya/
class ComplaintRepositoryTest {
    @Test
    fun submitComplaint_returnsSuccess() = runTest {
        // Mock API → assert Resource.Success
    }
}
```

### UI Tests (Espresso)
```kotlin
@Test
fun homeScreen_showsQuickActions() {
    ActivityScenario.launch(MainActivity::class.java)
    onView(withId(R.id.card_register_complaint)).check(matches(isDisplayed()))
}
```

Run tests:
```
./gradlew test           # Unit tests
./gradlew connectedTest  # Instrumented tests
```

---

## 11. Checklist Before Release

- [ ] `google-services.json` placed in `app/`
- [ ] `BASE_URL` updated to production API
- [ ] Phone OTP test numbers removed
- [ ] ProGuard rules verified
- [ ] All drawables added
- [ ] Permissions reviewed in Manifest
- [ ] Privacy Policy page created
- [ ] App tested on Android 7, 10, 13, 14
- [ ] Keystore backed up securely
- [ ] Release AAB generated and tested
- [ ] Play Store listing complete
- [ ] Content rating filled

---

## Support
Helpline: 1800-425-1515
Web: https://nammametro.in
